#include "../../src/visuallogjsobject.h"
