#include "../../src/visuallogmodel.h"
