#include "../../src/visuallogqt.h"
