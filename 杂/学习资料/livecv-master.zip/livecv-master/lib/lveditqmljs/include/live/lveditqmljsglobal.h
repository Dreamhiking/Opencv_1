#include "../../src/lveditqmljsglobal.h"
