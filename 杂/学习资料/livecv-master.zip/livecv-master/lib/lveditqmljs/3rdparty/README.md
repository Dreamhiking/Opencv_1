This section has been extracted from QtCreator and QtDeclarative sources.

**Live CV licenses do not apply here.**
