#include "../../src/editorsettingscategory.h"
