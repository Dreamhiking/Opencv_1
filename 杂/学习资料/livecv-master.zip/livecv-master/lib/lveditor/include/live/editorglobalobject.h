#include "../../src/editorglobalobject.h"
