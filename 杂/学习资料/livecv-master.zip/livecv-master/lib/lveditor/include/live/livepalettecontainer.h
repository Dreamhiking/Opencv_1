#include "../../src/livepalettecontainer.h"
