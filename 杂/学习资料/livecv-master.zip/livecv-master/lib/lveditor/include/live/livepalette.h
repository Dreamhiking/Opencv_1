#include "../../src/livepalette.h"
