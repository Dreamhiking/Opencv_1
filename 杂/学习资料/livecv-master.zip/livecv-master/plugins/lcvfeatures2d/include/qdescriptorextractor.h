#include "../src/qdescriptorextractor.h"
