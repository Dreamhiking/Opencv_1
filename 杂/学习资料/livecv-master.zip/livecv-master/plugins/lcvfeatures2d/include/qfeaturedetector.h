#include "../src/qfeaturedetector.h"
