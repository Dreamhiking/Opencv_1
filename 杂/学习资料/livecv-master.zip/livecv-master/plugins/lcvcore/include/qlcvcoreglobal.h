#include "../src/qlcvcoreglobal.h"
