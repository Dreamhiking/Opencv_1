#include <opencv2/opencv.hpp>    
    
using namespace cv;   
  /*
		��״��ȡ
  */
int main()   
{   
	IplImage* pCannyImg = NULL;
	IplImage* pImg = NULL;
    Mat img = imread("D:\\aa�Լ�ӢD\\רҵ�����ļ�\\visual C#\\OPenCVTest\\OPenCVTest\\REC0009_148.jpg",1);   
 // Mat img = imread("image.jpg");  
    Mat grey;  
    cvtColor(img, grey, CV_BGR2GRAY);  

   Mat sobelx;  
   Sobel(grey, sobelx, CV_32F, 1, 0);  

   double minVal, maxVal;  
    minMaxLoc(sobelx, &minVal, &maxVal); //find minimum and maximum intensities  
   Mat draw;  
   sobelx.convertTo(draw, CV_8U, 255.0/(maxVal - minVal), -minVal * 255.0/(maxVal - minVal));  

    namedWindow("1", CV_WINDOW_AUTOSIZE);  
    imshow("1",img); 
    imshow("",draw);  

//*pImg = IplImage(draw);

//pCannyImg = cvCreateImage(cvGetSize(&draw), IPL_DEPTH_8U, 1);
//cvCanny(&draw, pCannyImg, 100, 180, 3);
//cvNamedWindow("canny",1);
//cvShowImage( "canny", pCannyImg );
     waitKey();  
    
   return 0;   
}   